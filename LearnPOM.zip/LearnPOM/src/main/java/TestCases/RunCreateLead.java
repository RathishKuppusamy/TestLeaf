package TestCases;

import org.testng.annotations.Test;

import Base.BaseClass;
import Pages.LoginPage;
import Pages.WelcomePage;

public class RunCreateLead extends BaseClass{

	@Test
	public void runCreateLead() {

		LoginPage lp = new LoginPage(driver);

		lp.enterUname().enterPword().clickSubmit()
		.verifyLogin().clickCRMLink()
		.clickLeads()
		.myLeads()
		.enterCompName().enterFirstName().enterLastName().enterLocalName().enterDeptName().enterLeadDescription().enterLeadEmail().clickLeadSubmit()
		.verifyLeads();
	}
	
}
