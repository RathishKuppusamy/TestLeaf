package TestCases;

import org.testng.annotations.Test;

import Base.BaseClass;
import Pages.LoginPage;
import Pages.WelcomePage;

public class RunLogin extends BaseClass{

	@Test
	public void runLogin() {
		
		LoginPage lp = new LoginPage(driver);
		/*
		 * lp.enterUname(); lp.enterPword(); lp.clickSubmit();
		 * 
		 * WelcomePage wp = new WelcomePage(); wp.clickCRMLink();
		 * 
		 * --> While return statement is not added to each method, we need to call each method by creating object everytime.
		 */
		
		lp.enterUname().enterPword().clickSubmit().verifyLogin().clickCRMLink();
		// --> Creating object is not need everytime, since return statement is added
	}
	
}
