package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import Base.BaseClass;

public class WelcomePage extends BaseClass{
	
	public WelcomePage(ChromeDriver driver) {      
		this.driver = driver;					 
	}
	
	
	public WelcomePage verifyLogin() {
		String LogintTitle = driver.getTitle();
		System.out.println("The title of this page is: " + LogintTitle);
		return this;
	}
	
	public HomePage clickCRMLink()
	{
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new HomePage(driver);
	}
	
	
	

}
