package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import Base.BaseClass;

public class ViewLeadsPage extends BaseClass{
	
	public ViewLeadsPage(ChromeDriver driver) {      
		this.driver = driver;					 
	}	
	
	public ViewLeadsPage verifyLeads() {
		System.out.println("Lead created Succesfully: " +driver.getTitle());	
		return this;
	}

	
	

}
