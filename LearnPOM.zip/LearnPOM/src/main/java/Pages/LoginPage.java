package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import Base.BaseClass;

public class LoginPage extends BaseClass{
	
	public LoginPage(ChromeDriver driver) {      //Creating constructor and passing the driver
		this.driver = driver;					 //Assigning Global driver value to Local drivers
	}
	
	public LoginPage enterUname()
	{
		driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
		//LoginPage lp = new LoginPage();			-->Instead of creating object every time, we can use this
		//return lp;
		return this;                   //-->Since after clicking this button it does not navigate any page
	}
	
	public LoginPage enterPword()
	{
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		return this;
	}
	
	public WelcomePage clickSubmit()
	{
		driver.findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage(driver);      //-->Since after clicking this button it navigates to Welcome page
		//Where ever the constructor call happens, we need to pass the driver(for Parallel Execution)
		//Need to add constructor in WelcomePage as well..... same applies for all page where ever constructor call happens
	}
}
