package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import Base.BaseClass;

public class CreateLeadsPage extends BaseClass{
	
	public CreateLeadsPage(ChromeDriver driver) {     
		this.driver = driver;					 
	}
	
	public CreateLeadsPage enterCompName() {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys("Product");
		return this;
	}
	public CreateLeadsPage enterFirstName() {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys("Ratis");
		return this;
	}
	public CreateLeadsPage enterLastName() {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("K");
		return this;
	}
	public CreateLeadsPage enterLocalName() {
		driver.findElement(By.name("firstNameLocal")).sendKeys("Rat");
		return this;
	}
	public CreateLeadsPage enterDeptName() {
		driver.findElement(By.id("createLeadForm_departmentName")).sendKeys("IT");
		return this;
	}
	public CreateLeadsPage enterLeadDescription() {
		driver.findElement(By.id("createLeadForm_description")).sendKeys("For testing purpose only");
		return this;
	}
	public CreateLeadsPage enterLeadEmail() {
		driver.findElement(By.id("createLeadForm_primaryEmail")).sendKeys("rat00@mail.com");
		return this;
	}
	
	//DOUBT
	
	/*public void enterLeadState) {
		WebElement dropdown = driver.findElement(By.id("createLeadForm_generalStateProvinceGeoId"));
		Select state = new Select(dropdown);
		state.selectByVisibleText("New York");
	}*/
	
	public ViewLeadsPage clickLeadSubmit() {
		driver.findElement(By.name("submitButton")).click();
		return new ViewLeadsPage(driver);
	}
}

