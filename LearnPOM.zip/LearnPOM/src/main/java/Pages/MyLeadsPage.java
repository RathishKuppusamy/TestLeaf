package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import Base.BaseClass;

public class MyLeadsPage extends BaseClass{
	
	public MyLeadsPage(ChromeDriver driver) {      
		this.driver = driver;					 
	}
	
	
	public CreateLeadsPage myLeads() {
		driver.findElement(By.xpath("//a[text()='Create Lead']")).click();
		return new CreateLeadsPage(driver);
	}

	
	

}
