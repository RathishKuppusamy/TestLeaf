
public class Notes {

	/* For DOM freeze
	setTimeout(function(){debugger;},7000) */
	
	/*
	 * Stale Element explanation
	 * https://babu-testleaf.medium.com/the-untold-story-stale-element-reference-
	 * exception-in-selenium-9a334ea3b549
	 */
}
