package week3.day2.assignment;

//Override
public class BankInfo {
	
	public void saving() {
		System.out.println("Save money");
	}
	
	public void fixed() {
		System.out.println("Through fixed deposit");
	}
	
	public void deposit() {
		System.out.println("Deposit money");
	}

}
