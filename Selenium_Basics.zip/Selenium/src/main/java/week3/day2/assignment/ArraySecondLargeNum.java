package week3.day2.assignment;

import java.util.Arrays;

public class ArraySecondLargeNum {

	public static void main(String[] args) {
		 int[] arr = {3,2,11,4,6,7};
		 Arrays.sort(arr);
		 
		 System.out.println(arr[arr.length-2]);

	}

}
