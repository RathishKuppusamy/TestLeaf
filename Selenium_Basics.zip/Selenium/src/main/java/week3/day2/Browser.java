package week3.day2;

//overloading
public interface Browser {

	public void startApp();
	
	public void startApp(String browser);
	
}
