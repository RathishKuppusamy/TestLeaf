package week3.day2;

//overload

public class BrowserExecution {

	public static void main(String[] args) {
		BrowserImplementation bi = new BrowserImplementation();
		bi.startApp();
		bi.startApp("edge");

	}

}
