package week3.day1;

//inheritance
public class Iphone extends ios{
	
	public void makeCall() {
		System.out.println("Make a call");
	}
	
	public void sendSms() {
		System.out.println("Send a message");
	}

}
