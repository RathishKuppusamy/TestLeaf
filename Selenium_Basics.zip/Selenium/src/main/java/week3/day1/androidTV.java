package week3.day1;

//interface
public abstract class androidTV implements android{

	public void openApp() {
		System.out.println("open abstract class");
	}
	
}
