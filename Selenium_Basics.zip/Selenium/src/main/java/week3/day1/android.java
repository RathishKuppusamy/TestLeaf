package week3.day1;

//interface
public interface android {
	
	public void openApp();
	
	public void playVideo();

}
