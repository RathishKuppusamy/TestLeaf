package week3.day1;

//interface
public class samsung implements android{

	@Override
	public void openApp() {
		System.out.println("open samsung app ");
		
	}

	@Override
	public void playVideo() {
		
		System.out.println("play video");
	}

}
	
