package week3.day1.assignment;

//Multilevel inheritance
public class College {
	
public void collegeName() {
	System.out.println("College Name is: Karpagam college of Engineering");
}

public void collageCode() {
	System.out.println("College Code is: 01234");
}

public void collageRank() {
	System.out.println("College Rank is: 5");
}
	
}