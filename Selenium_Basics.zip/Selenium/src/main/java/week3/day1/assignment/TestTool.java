package week3.day1.assignment;

//Abstract
public interface TestTool extends Language {

	public void selenium();
	
}
