package week3.day1.assignment;

//Multilevel inheritance
public class Department extends College {
	
	public void deptName() {
		System.out.println("Department Name is: Information Technology");
	}

}