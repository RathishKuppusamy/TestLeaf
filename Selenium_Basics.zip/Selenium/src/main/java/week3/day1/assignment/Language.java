package week3.day1.assignment;

//Abstract
public interface Language {

	public void java();
	
}
