package week3.day1.assignment;

//Inheritance1
public class Computer {
	
	public void computerModel() {
		String s = "Asus";
		int i = 1241;
		System.out.println("Model name is: "+s +i);		
	}

}
