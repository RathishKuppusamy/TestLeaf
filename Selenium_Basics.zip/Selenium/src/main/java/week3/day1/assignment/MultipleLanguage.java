package week3.day1.assignment;

//Abstract
public abstract class MultipleLanguage implements TestTool{

	public void python() {
		System.out.println("Python");
	}
	
	public abstract void ruby();
	
}
