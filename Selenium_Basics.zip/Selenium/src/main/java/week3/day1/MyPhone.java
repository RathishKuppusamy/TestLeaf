package week3.day1;

public class MyPhone {

	public static void main(String[] args) {
		
		Iphone i = new Iphone();
		
		i.startApp();
		i.increaseVolume();
		i.shutDown();
		i.sendSms();
		i.makeCall();

	}

}
