package week3.day1;

//inheritance
public class Ipad extends ios{

	public void watchMovie() {
		System.out.println("Watch a movie");
	}
	
}
