package week3.day1;

//interface
public class onePlus {

	public static void main(String[] args) {
		
		samsung s = new samsung();
				
		s.openApp();
		s.playVideo();
		

	}

}
