package week3.day1;

//inheritance
public class ios {

	public void startApp() {
		System.out.println("Start the application");
	}
	
	public void increaseVolume() {
		System.out.println("Increase the volume");
	}
	
	public void shutDown() {
		System.out.println("Shut down the application");
	}
}
