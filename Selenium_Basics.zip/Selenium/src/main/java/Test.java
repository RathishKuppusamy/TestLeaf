import java.util.Iterator;

public class Test {
	
public static void main(String[] args) {
	int count = 0;
	do {
		System.out.println("Test Leaf");
		count++;
	}
	while(count<10);
	}
}