package week1.day1;

public class CheckPositiveOrNegative {

	public static void main(String[] args) {
		
	int num = -35;
	if(num > 0) {
		
		System.out.println("The number is positive.");
	}
	else if(num < 0) {
		
		System.out.println("The number is Negative.");
	}
	else {
		
		System.out.println("The number is neither Positive nor Negative.");
	}
	}

}
