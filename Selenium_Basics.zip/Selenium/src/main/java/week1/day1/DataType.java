package week1.day1;

public class DataType {

	public static void main(String[] args) {
		int num = 100;
		String name = "Rat";
		boolean hadTea = true;
		float deci = 100.5F;
		long cc = 1254789652563254L;
		double deci2 = 100.45879;
		char initial = 'K';
		byte rollNum = 1;
		short rupees = 10;
		
		System.out.println("The number is: "+ num);
		System.out.println("The name is: "+ name);
		System.out.println("You had tea?: "+ hadTea);
		System.out.println("The decimal point is: "+ deci);
		System.out.println("The credit card number is: "+ cc);
		System.out.println("The decimal point is: "+ deci2);
		System.out.println("The Initial is: "+ initial);
		System.out.println("The roll number is: "+ rollNum);
		System.out.println("The amount is: "+ rupees);
		
	}

}
